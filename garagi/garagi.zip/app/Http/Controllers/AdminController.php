<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\User;

class AdminController extends Controller
{
    public function getTechniciens(){
        $techniciens = User::all();
        $response = response([
            "techniciens"=>$techniciens
        ],201);
    }
}
